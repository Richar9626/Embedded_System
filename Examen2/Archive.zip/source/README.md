# Equipo8_P3
UART and I2C implementation
