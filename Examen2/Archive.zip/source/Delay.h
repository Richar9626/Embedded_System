/*
 * Delay.h
 *
 *  Created on: 11 feb. 2021
 *      Author: LUISPIZANO
 */

#ifndef DELAY_H_
#define DELAY_H_

#include <stdint.h>

void delay(uint32_t delay);

#endif /* DELAY_H_ */
